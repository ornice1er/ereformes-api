<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use eloquentFilter\QueryFilter\ModelFilters\Filterable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class Document extends Model
{
    use Filterable, HasFactory,SoftDeletes;

    protected $fillable = [
        'titre',
        'description',
        'chemin',
        'type',
        'statut',
        'date_depot',
        'dossier_id',
        'user_id'
    ];

    protected $dates = ['date_depot'];

    public function dossier()
    {
        return $this->belongsTo(Dossier::class);
    }

    public function metadonnees()
    {
        return $this->hasMany(Metadonnee::class);
    }

    public function utilisateur()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}

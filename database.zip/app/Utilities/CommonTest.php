<?php

namespace App\Utilities;

final class CommonTest {}

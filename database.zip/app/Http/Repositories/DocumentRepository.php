<?php
namespace App\Http\Repositories;

use App\Models\Document;
use App\Traits\Repository;
use App\Utilities\FileStorage;

class DocumentRepository
{
    use Repository;

    protected $model;

    public function __construct()
    {
        $this->model = app(Document::class);
    }

    public function getAll($request)
    {
        return Document::with(['dossier', 'metadonnees'])
            ->filter($request->all())
            ->orderByDesc('created_at')
            ->paginate($request->per_page ?? 10);
    }

    public function get($id)
    {
        return $this->findOrFail($id);
    }

    public function makeStore($data)
    {
        if (request()->hasFile('fichier')) {
            $path = FileStorage::setFile('documents', request()->file('fichier'), 'archives');
            $data['chemin'] = $path;
        }

        $document = Document::create($data);

        if (!empty($data['metadonnees'])) {
            $document->metadonnees()->createMany($data['metadonnees']);
        }

        return $document->load('metadonnees');
    }

    public function makeUpdate($id, $data)
    {
        $document = Document::findOrFail($id);

        if (request()->hasFile('fichier')) {
            FileStorage::deleteFile('documents', $document->chemin);
            $data['chemin'] = FileStorage::setFile('documents', request()->file('fichier'), 'archives');
        }

        $document->update($data);

        if (isset($data['metadonnees'])) {
            $document->metadonnees()->delete();
            $document->metadonnees()->createMany($data['metadonnees']);
        }

        return $document;
    }

    public function makeDestroy($id)
    {
        $document = Document::findOrFail($id);
        FileStorage::deleteFile('documents', $document->chemin);
        return $document->delete();
    }

    public function search($term)
    {
        return Document::where('titre', 'like', "%$term%")->get();
    }
}

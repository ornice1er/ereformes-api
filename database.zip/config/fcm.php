<?php

return [
    // 'server_key' => env('FIREBASE_SERVER_KEY'),
    'credentials' => env('FIREBASE_CREDENTIALS'),
];

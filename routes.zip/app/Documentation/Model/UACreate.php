<?php

namespace App\Documentation\Model;

/**
 * Class UACreate
 *
 * @OA\Schema(
 *     schema="UACreate",
 *     title="UACreate class",
 *     description="UACreate class",
 * )
 */
class UACreate
{
    /**
     * @OA\Property()
     *
     * @var string
     */
    private $libelle;
}

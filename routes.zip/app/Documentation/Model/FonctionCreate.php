<?php

namespace App\Documentation\Model;

/**
 * Class FonctionCreate
 *
 * @OA\Schema(
 *     schema="FonctionCreate",
 *     title="FonctionCreate class",
 *     description="FonctionCreate class",
 * )
 */
class FonctionCreate
{
    /**
     * @OA\Property()
     *
     * @var string
     */
    private $libelle;
}

<?php

namespace App\Documentation\Model;

/**
 * Class StatutCreate
 *
 * @OA\Schema(
 *     schema="StatutCreate",
 *     title="StatutCreate class",
 *     description="StatutCreate class",
 * )
 */
class StatutCreate
{
    /**
     * @OA\Property()
     *
     * @var string
     */
    private $libelle;
}
